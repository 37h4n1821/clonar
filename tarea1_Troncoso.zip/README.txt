El programa se compone de un solo archivo ".c", el cual posee el código de todo el programa, incluyendo la implementacion de las funciones.
Además se posee un archivo header (".h") que define los formatos de nuestras funciones

El archivo debe ser compilado con un nombre a libre elección en un compilador del lenguaje C, donde se incluya en la misma carpeta el header con la definicion de nuestras funciones.

El programa debe ser ejecutado con un argumento de entrada por línea de comando que especifique el nombre del archivo con palabras para utilizar como sugerencias.


EJ:

gcc tarea1.c -o ejecutable

Ejecución en Linux:

./ejecutable davincicode.txt

Ejecución en Windows:

.\ejecutable.exe davincicode.txt