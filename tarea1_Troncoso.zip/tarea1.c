#include "tarea1.h"

int main(int argc, char *argv[]){

        char cadena[99],*cadena_;

        if (argc!=2){ //Si se pasan mas argumentos o menos argumentos de los necesarios
                printf("Cantidad de argumentos invalidos!");
                exit(EXIT_FAILURE); 
        }

        FILE* input_file = fopen(argv[1], "r");
        
        if (!input_file){
                printf("Archivo: %s no encontrado",argv[1]);
                exit(EXIT_FAILURE);
        }

        TrieNode* trie = leer_archivo(input_file); //Se procesa el texto del archivo abierto en modo lectura al trie
        fclose(input_file);

        while(1){
                printf("Ingrese cadena a analizar: ");
                char str[MAX_LIMIT]; //Char array con la cadena que ingresara el usuario
                fgets(str, MAX_LIMIT, stdin); //Se obtiene la cadena que desea el usuario a traves de la consola
                
                int len = strlen(str); 
                int temp; //Un contador para recorrer el char array del usuario
                for (temp=0;temp<len;temp++){
                        str[temp]=minAmay(str[temp]); //Se transforman todas las minusculas ingresadas por el usuario en mayusculas
                }
                str[len - 1] = '\0';
                printf("%s -> ", str); //Se imprime por pantalla las letras ingresadas por el usuario ya transformadas
                if(strlen(str)==0){ //Si se ingresa INTRO solamente (vacio) se termina el ciclo
                        printf("Hasta luego");
                        break;
                }
                cadena_=str; //Se le pasa al puntero de char el char array obtenido del usuario
                coincidence(trie,cadena_); //Se llama a la funcion que busca las sugerencias
                
        }
        destroyTrie(trie); //Al terminar el ciclo se libera y destruye el arbol
        return 0; //Se finaliza el programa
}

TrieNode *insertNode(TrieNode *tr, char c){
        tr = (TrieNode *)malloc(sizeof(TrieNode)); //Se asigna espacio en la memoria para el nodo a insertar
        tr->letter = c; //Se le asigna la letra correpondiente a ese nodo
        
        int i;

        for(i=0;i<ALPHABET_SIZE;i++){
                tr->child[i]=NULL; //Se dejan a los hijos del nuevo nodo apuntando a NULL
        }
        return tr; //Se retorna el nuevo nodo
}

void insertWord(TrieNode *tr, char *word){
        TrieNode *tmp = tr; //Se crea un puntero al comienzo del trie
        int large = strlen(word); //Largo de la palabra
        int i,i2,i3;
        for(i=0;i<large;i++){ //Se recorre la palabra que se quiere ingrese
                for (i2=0;i2<ALPHABET_SIZE;i2++){ //Se recorre los hijos del nodo en el que estamos parados
                        if (tmp->child[i2]==NULL){ //Si el hijo del nodo es NULL (no pertenece a ninguna palabra)
                                tmp->child[i2]=insertNode(tmp->child[i2],word[i]); //Se le inserta un nodo con la letra que queremos insertar por ahora
                                break; //Se termina el reccorido de los hijos del nodo en el que estamos parados
                        }else{ //Sino...
                                if(tmp->child[i2]->letter==word[i]){ //Si el hijo actual tiene la letra que queremos insertar simplemente se termina el recorrido de los hijos
                                        break;
                                }
                        } //Si no ocurre ninguno de los casos anteriores, se sigue avanzando por los hijos del nodo en el que estamos parados
                }
                tmp=tmp->child[i2]; //Como ya se conoce la posición con el hijo de interes (ya sea por ya estar o no estar la letra) nuestro puntero tmp avanza a apuntar al hijo de interes
        }
        for(i3=0;i3<ALPHABET_SIZE;i3++){ //Cuando ya se termina de insertar la palabra nueva en el trie, con el puntero tmp vamos a estar parado en una hoja del trie que desciende de nuestra nueva palabra 
                if(tmp->child[i3]==NULL){ //Se busca el primer hijo NULL de la hoja descendiente de la nueva palabra
                        tmp->child[i3]=insertNode(tmp->child[i3],'*'); //En ese hijo NULL se le inserta un nodo con el asterisco que indica el final de la palabra
                        break; //Como ya encontramos el hijo de interes, terminamos el recorrido de los hijos
                }
                if(tmp->child[i3]->letter=='*'){ //Si la palabra completa ya existia, entonces solo se termina el ciclo que recorre los hijos y no se modifica nada
                        break;
                }
        }
}

void deleteWord(TrieNode *tr, char *word){

        TrieNode *tmp = tr; //Se crean 2 nodos temporales
        TrieNode *tmp2;

        char palabra[strlen(word)]; //Se crea un char array del tamaño de la palabra que se quiere borrar
        strcpy(palabra,word); //Se copian los strings de word (palabra original) a el char array nuevo
        strcat(palabra,"*"); //Se le concadena un asterisco para tener el verdadero char que tiene el arbol

        word=&palabra[0]; //El puntero a char "word" lo dejamos apuntando al primer char del nuevo char array

        int large = strlen(word);
        int i,i2,i3,check=0;
        

        for(i3=large-1;i3>=0;i3--) //Se recorre el char que queremos borrar desde adelante hacia atras
        {
                for(i=0;i<=i3;i++){ //Estos for anidados son para recorrer el trie por la rama que contiene la palabra de interes
                        for (i2=0;i2<ALPHABET_SIZE;i2++){
                                if(tmp->child[i2]->letter==word[i]){
                                        break;
                                }
                        }
                        tmp2=tmp; //Se tiene un puntero tmp2 apuntando al padre del hijo de interes
                        tmp=tmp->child[i2]; //Se tiene otro puntero tmp que apunta al hijo de interes
                }
                //Ahora que estamos en el final de la palabra, se evaluan diferentes casos de los hijos con el padre tmp2, y al elegir el hijo se borra con el tmp que apunta al hijo de interes
                if(i2==0 && tmp2->child[1]==NULL){ //Si el hijo de interes es el primero y unico exitente simplemente se anula
                        tmp2->child[0]=NULL;
                }else{ //Sino...
                        if(tmp2->child[i2+1]!=NULL){ //Si el hijo de interes esta entremedio pero el resto de hermanos a la derecha no son NULL, se van rotando todos estos hermanos un indice a la izquiera, borrando el hijo de interes ya que la rotacio comienza desde su hermano de la derecha
                                for (i2;i2<ALPHABET_SIZE-1;i2++){
                                        tmp2->child[i2]=tmp2->child[i2+1];
                                }
                                tmp2->child[i2+1]=NULL; //Como corrimos todos los hermanos de la derecha 1 indice a la izquiera, la antigua posicion del ultimo hermano no NULL queda con contenido random, por lo que lo estandarizamos a NULL
                                break;
                        }else{
                                tmp2->child[i2]=NULL; //Sino ocurre ninguno de los casos anteriores, significa que el hijo que queremos borrar es el ultimo no NULL
                        }
                        //Toda esta "burocracia" realizada es para mantener a todos los hijos no nulos de manera continua y no tener que recorrer a los 29 hijos por estar desordenados
                }
                //El puntero tmp vuelve a apuntar a nuestro puntero original
                tmp=tr;
        }


}


int wordExist(TrieNode *tr, char *word){
        TrieNode *tmp = tr; //Se crea un puntero temporal

        char palabra[strlen(word)]; //Se crea un char array del tamaño de la palabra que se quiere borrar
        strcpy(palabra,word); //Se copian los strings de word (palabra original) a el char array nuevo
        strcat(palabra,"*"); //Se le concadena un asterisco para tener el verdadero char que tiene el arbol

        word=&palabra[0]; //El puntero a char "word" lo dejamos apuntando al primer char del nuevo char array

        int large = strlen(word); 
        int i,i2,c=0; //c es para contar la profundidad del trie y ver si coincide con el largo de la palabra
        for(i=0;i<large;i++){ //Estos for anidados son para recorrer el trie por la rama que contiene la palabra de interes
                for (i2=0;i2<ALPHABET_SIZE;i2++){
                        if(tmp->child[i2]==NULL){ 
                                break;
                        }
                        if(tmp->child[i2]->letter==word[i]){
                                c++; //Va sumando 1 por nivel que se avanza
                                break;
                        }
                }
                tmp=tmp->child[i2];
        }
        if(c==large){
                return 1; //Si la profundidad coincide con el largo de la palabra, se retorna 1 (true)
        }
        return 0; //Sino se retorna 0 (false)
}

TrieNode *leer_archivo(FILE* input_file){
        TrieNode *trie = insertNode(trie,'-'); //Se  inserta el nodo "vacio" en la raiz

        char ch;
        char palabra[99],*palabra_;
        int ch_,i=0,linea=1;
        do {
                ch = fgetc(input_file); //Se obtiene caracter por caracter del archivo
                ch=minAmay(ch); //Cada caracter se pasa de minuscula a mayuscula
                if(ch>=65 && ch<=90){ //Si el ASCII de la letra esta en el rango del ASCII de las letras del abecedario en mayuscula
                        palabra[i]=ch; //Se añade al char array los caracteres que si son letras mayusculas
                        i++; //Se avanza en el indice que ordena el char array

                }else{
                        if(ch=='\n'){ // Si el caracter obtenido del arcchivo es un salto de linea
                                linea++; //Se suma 1 al int con la cantidad de lineas
                        }
                        palabra_=palabra; //Puntero char apunta a nuestro char array
                        if(strlen(palabra_)!=0){ //Si el tamaño de lo contenido por el puntero a char es distinto de 0
                                insertWord(trie, palabra_); //Significa que tenemos una palabra que agragar, por lo tanto la agregamos
                        }
                        
                        palabra_=NULL; //Se vuelve a dejar apuntando a NULL nuestro puntero a char "comunitario" (que servira a todas la palabras que se agreguen)
                        int i2;
                        for(i2=0;i2<99;i2++){
                                palabra[i2]='\0'; //Se dejan todos los char del char array con un contenido reemplazable por las proxima palabras
                        }
                        
                        i=0; //Se reinicia el indice que no ayuda a ordenar el char array
                }
        } while (ch != EOF); //Ciclo que solo terminara con el fin del archivo

        return trie; //Cuando ya se terminan de almacenar en el trie todas las palabras de interes, se retorna el trie
}

void coincidence(TrieNode *tr, char *word){
        TrieNode *tmp = tr; //Se crea un puntero temporal
        int large = strlen(word);
        int i,i2,i3;
        char *rest;
        for(i=0;i<large;i++){  //Estos for anidados son para recorrer el trie por la rama que contiene la palabra de interes
                for (i2=0;i2<ALPHABET_SIZE;i2++){
                        if(tmp->child[i2]==NULL){ //Se se llega a un hijo NULL, significa que no encontro un hijo coincidente con la letra que buscamos, entonces la palabra de interes no esta en el trie
                                printf("No se encontraron coincidencias\n");
                                return;
                        }
                        else if(tmp->child[i2]->letter==word[i]){ //Si es que encuentra un nodo hijo con la letra que buscamos, se termina el recorrido de hijos
                                break;
                        }
                }
                tmp=tmp->child[i2]; //Se avanza por el hijo de interes que se tiene identificado con i2
        }
        printf("Palabras sugeridas: \n"); //Comienza la impresion de todas las palabras derivadas de la cadena word
        imprimir_nodos(tmp,i+1,word);
}


void imprimir_nodos(TrieNode *tr,int i,char *word){
        char temporal[99];///creamos un char temporal para almacenar la palabra
        strncpy(temporal, word, i); //copiamos la palabra respecto a que nivel del arbol necesitemos
        temporal[i] = '\0'; //agregamos el char de finalizacion del string
        TrieNode *tmp = tr;
        int i2;
        for (i2=0;i2<ALPHABET_SIZE;i2++){
                if(tmp->child[i2]==NULL){///si el hijo es nulo finalizamos 
                        return;
                }else{
                        if(tmp->child[i2]->letter!='*'){///si no es nulo y su caracter es distinto de * lo sumamos
                                temporal[i-1]=tmp->child[i2]->letter;///sumamos el caracter en la posicion anterior de \0 
                                temporal[i]='\0';//generamos la nueva posicion del \0 
                                strcpy(word,temporal);/// lo transpasamos al puntero
                                
                                
                                imprimir_nodos(tmp->child[i2],i+1,word);///llamamos de manera recursiva la funcion para asi continuar la busqueda indicando en que nivel del arbol estamos
                        }else{
                                printf("->>%s\n",word);//si encontramos el * imprimimos la palabra
                        } 
                }
        }
        

}

void destroyTrie(TrieNode *tr){
        TrieNode *tmp=tr; ////Se crea un puntero temporal
	int i;
	for(i=0; i<ALPHABET_SIZE; i++){
		if(tmp->child[i]!=NULL){ //Se va recorriendo hijo por hijo no NULL para ir recursivamente borrandole los nodos
			destroyTrie(tmp->child[i]);
		}
                free(tmp->child[i]); //Cuando ya se llegan a las hojas se comienzan a liberar
		
	}
}

char minAmay(char ch){
        if(ch>=97 && ch<=122){ //Si el ASCII de las letras esta en el rango del ASCII de las letras minusculas
                ch=ch-32; //Se resta 32 para pasar del ASCII de las letras minusculas a mayusculas
        }
        return ch;
}