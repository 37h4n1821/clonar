#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define ALPHABET_SIZE 29
#define MAX_LIMIT 99 //Se define un maximo de letras para las palabras

typedef struct mtrie{
        char letter;
        struct mtrie *child [ALPHABET_SIZE];
}TrieNode;

//Funcion que busca las palabras coincidentes de un char especifico
void coincidence(TrieNode *tr, char *word);

// Funcion que permite procesar el texto y crear el arbol
TrieNode *leer_archivo(FILE* input_file);

// Funcion que permite ingresar al trie una nueva palabra
void insertWord(TrieNode *tr, char *word);

// Funcion que permite eliminar del trie alguna palabra
void deleteWord(TrieNode *tr, char *word);

// Funcion que verifica si la palabra word se encuentra o no en el trie
int wordExist(TrieNode *tr, char *word);

// Funcion que permite agregar el caracter c al nodo apuntado por tr
TrieNode *insertNode(TrieNode *tr, char c);

// Funcion que permite agregar imprime los nodos hijos
void imprimir_nodos(TrieNode *tr,int i,char *word);

//Funcion que destruye el arbol con las palabras completo
void destroyTrie(TrieNode* tnode);

//Funcion que transforma un char de minusculas a mayusculas
char minAmay(char ch);
